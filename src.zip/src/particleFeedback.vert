#version 420
#extension GL_ARB_enhanced_layouts : enable

layout(location = 0) in vec4 v;

uniform mat4 P;
uniform float screen_x;
uniform float screen_y

out vec4 position;

void main()
{
	float x = x0 + v[0];
	float z = z0 + v[1];
	float xfreq = 2 * 1.7;
	float zfreq = 2 * 2.1;
	float y     =  cos(xfreq * x) * cos(zfreq * z);
	float dydx  = -xfreq * sin(xfreq * x) * cos(zfreq * z);
	float dydz  = -zfreq * sin(zfreq * z) * cos(xfreq * x);
	
	position  = vec3(x, y, z);
	normal    = normalize(vec3(-dydx, 1.0, -dydz));
	texCoord  = v; // todo

	gl_Position = vec4(position, 1.0);
}
